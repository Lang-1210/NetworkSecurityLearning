package ysoserial.test;


/**
 * @author mbechler
 *
 */
public interface CustomDeserializer {


    Class<?> getCustomDeserializer ();

}
