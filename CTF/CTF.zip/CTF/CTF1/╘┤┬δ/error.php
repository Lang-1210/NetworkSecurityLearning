<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404</title>
</head>

<body>

    <body bgcolor="white">
        <center>
            <h1>Access Denied</h1>
        </center>
        <hr>
        <center>깃발 1은 아래 사진에 있습니다.</center>
        <center>
            <img src="./5527eaab87a00dbe1614481ef174f285/0b63ac48a76039934e8062aec5c7b8ba.jpg" alt="">
        </center>
    </body>
</body>

</html>