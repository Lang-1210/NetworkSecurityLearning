<?php
header('location:./error.php');
setcookie("PHPSESSID", "ZmxhZ3s1OTQzamZsZG1sZjQwMzJsZG9wcm99", time() + 3600);
?>
<html>

<head>
    <title>index</title>
</head>

<body bgcolor="white">
    <center>
        <h1>WELCOME TO MY HOMEPAGE</h1>
    </center>
    <hr>
    <center>FLAG IS HERE</br>
        <!--<p>..-. .-.. .- --. ----.-- ....- ..... .---- ..-. -.. ... ..-. ....- ....- -.... ..... ..-. ... -----.-</p>-->
    </center>

</body>

</html>