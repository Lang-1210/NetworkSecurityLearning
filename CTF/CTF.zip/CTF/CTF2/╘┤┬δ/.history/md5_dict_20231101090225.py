import hashlib

passwords = [
    '123456',
    'password',
    'qwerty',
    'admin',
    'hello',
    'flag{md53454kfodkfkfdsmd5}'
]

with open('md5_dictionary.txt', 'w') as f:
    for password in passwords:
        md5_hash = hashlib.md5(password.encode()).hexdigest()
        f.write(f"{password}:{md5_hash}\n")
