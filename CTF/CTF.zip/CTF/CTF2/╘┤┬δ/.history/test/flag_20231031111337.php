<?php
$flag = "flag{8543jkfdlfd8054klfdlfjl}";
?>