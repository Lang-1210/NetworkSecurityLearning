<?php
$html.=<<<A
<p class=nabname>
我是文件1
</p>
A;
?>