<?php
$html.=<<<A
<p class=nabname>
我是文件3
</p>
A;
?>