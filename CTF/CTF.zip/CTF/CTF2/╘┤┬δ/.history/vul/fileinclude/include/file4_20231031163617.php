<?php
$html.=<<<A
<p class=nabname>
4
</p>
A;
?>