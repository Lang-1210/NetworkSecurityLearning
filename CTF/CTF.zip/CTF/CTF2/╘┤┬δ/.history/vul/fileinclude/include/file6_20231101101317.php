<?php
$html .= <<<A
<p class=nabname>
我是文件6
</p>
A;
?>