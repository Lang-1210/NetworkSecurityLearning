<?php
$html.=<<<A
<p class=nabname>
5
</p>
A;
?>