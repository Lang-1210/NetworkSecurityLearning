<?php
$html.=<<<A
<p class=nabname>
我是文件2
</p>
A;
?>