<?php
$html.=<<<A

<p class=nabname>
1
</p>
A;
?>