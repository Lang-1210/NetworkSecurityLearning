<?php
$html.=<<<A
<p class=nabname>
3
</p>
A;
?>