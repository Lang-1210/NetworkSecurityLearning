<?php
$html.=<<<A
<p class=nabname>
2
</p>
A;
?>