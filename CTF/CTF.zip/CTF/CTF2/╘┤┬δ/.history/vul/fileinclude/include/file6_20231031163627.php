<?php
$html .= <<<A
<p class=nabname>
6
</p>
A;
?>