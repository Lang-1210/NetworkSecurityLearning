<?php
$html.=<<<A
<p class=nabname>
我是文件5
</p>
A;
?>