<?php
$html.=<<<A

<p class=nabname>

</p>
A;
?>