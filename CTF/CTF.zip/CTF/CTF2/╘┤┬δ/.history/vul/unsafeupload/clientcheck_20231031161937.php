<?php
/**
 * Created by runner.han
 * There is nothing new under the sun
 */


$SELF_PAGE = substr($_SERVER['PHP_SELF'], strrpos($_SERVER['PHP_SELF'], '/') + 1);

if ($SELF_PAGE = "clientcheck.php") {
    $ACTIVE = array('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'active open', '', 'active', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
}
$PIKA_ROOT_DIR = "../../";
include_once $PIKA_ROOT_DIR . 'header.php';
include_once $PIKA_ROOT_DIR . 'inc/uploadfunction.php';

$html = '';
if (isset($_POST['submit'])) {
    //     var_dump($_FILES);
    $save_path = 'uploads'; //指定在当前目录建立一个目录
    $upload = upload_client('uploadfile', $save_path); //调用函数
    if ($upload['return']) {
        $html .= "<p class='notice'>文件上传成功</p><p class='notice'>文件保存的路径为：{$upload['new_path']}</p>";
    } else {
        $html .= "<p class=notice>{$upload['error']}</p>";
    }
}


?>

<div class="main-content">
    <div class="main-content-inner">

        <div class="page-content">
            <div id="usu_main">
                <p class="title">这里只允许上传图片o！</p>
                <form class="upload" method="post" enctype="multipart/form-data" action="">
                    <input class="uploadfile" type="file" name="uploadfile" onchange="checkFileExt(this.value)" /><br />
                    <input class="sub" type="submit" name="submit" value="开始上传" />
                </form>
                <?php
                echo $html; //输出了路径，暴露了
                ?>
            </div>

        </div><!-- /.page-content -->
    </div>
</div><!-- /.main-content -->




<script>
    function checkFileExt(filename) {
        var flag = false; //状态
        var arr = ["jpg", "png", "gif"];
        //取出上传文件的扩展名
        var index = filename.lastIndexOf(".");
        var ext = filename.substr(index + 1);
        //比较
        for (var i = 0; i < arr.length; i++) {
            if (ext == arr[i]) {
                flag = true; //一旦找到合适的，立即退出循环
                break;
            }
        }
        //条件判断
        if (!flag) {
            alert("上传的文件不符合要求，请重新选择！");
            location.reload(true);
        }
    }
</script>


<?php
include_once $PIKA_ROOT_DIR . 'footer.php';

?>