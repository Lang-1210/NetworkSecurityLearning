<?php
/**
 * Created by runner.han
 * There is nothing new under the sun
 * */

include_once 'inc/config.inc.php';

include "header.php";

$html = "";
try {
    mysqli_connect(DBHOST, DBUSER, DBPW, DBNAME);
} catch (Exception $e) {
    $html .=
        "<p >
        <a href='install.php' style='color:red;'>
        提示:欢迎使用,pikachu还没有初始化，点击进行初始化安装!
        </a>
    </p>";
}

?>

<div class="main-content">
    <div class="main-content-inner">
        <!--  <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li class="active">系统介绍</li>
            </ul>
        </div> -->
        <div class="page-content">
            <?php echo $html; ?>
            <div id="intro_main">
                <p class="p1">
                    <img src="./vul/unsafeupload/uploads/01.png" alt="">
                </p>
            </div>


        </div><!-- /.page-content -->
    </div>
</div><!-- /.main-content -->



<?php
include "footer.php";
?>