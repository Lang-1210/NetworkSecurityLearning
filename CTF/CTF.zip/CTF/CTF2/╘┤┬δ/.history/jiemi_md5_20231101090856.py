# e0dfb111be8e4a82f928bc87efc3b2b9
import hashlib

def md5_decrypt(md5_hash, dictionary_file):
    with open(dictionary_file, 'r') as f:
        for line in f:
            line = line.strip()
            print(line)
            if hashlib.md5(line.encode()).hexdigest() == md5_hash:
                return line
    return None

md5_hash = input("请输入要解密的 MD5 值: ")
dictionary_file = "./md5_dictionary.txt"  # 替换为你自己的 MD5 字典文件路径

result = md5_decrypt(md5_hash, dictionary_file)
if result:
    print("解密结果:", result)
else:
    print("未找到匹配的明文")
