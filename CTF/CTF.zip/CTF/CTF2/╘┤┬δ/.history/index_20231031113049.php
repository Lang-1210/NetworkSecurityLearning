<?php
/**
 * Created by runner.han
 * There is nothing new under the sun
 * */

include_once 'inc/config.inc.php';

include "header.php";

$html = "";
try {
    mysqli_connect(DBHOST, DBUSER, DBPW, DBNAME);
} catch (Exception $e) {
    $html .=
        "<p >
        <a href='install.php' style='color:red;'>
        提示:欢迎使用,pikachu还没有初始化，点击进行初始化安装!
        </a>
    </p>";
}

?>

<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li class="active">系统介绍</li>
            </ul>
        </div>
        <div class="page-content">
            <?php echo $html; ?>
            <div id="intro_main">
                <p class="p1">
                    Pikachu是一个带有漏洞的Web应用系统，在这里包含了常见的web安全漏洞。
                    如果你是一个Web渗透测试学习人员且正发愁没有合适的靶场进行练习，那么Pikachu可能正合你意。
                </p>

                </p>




            </div>


        </div><!-- /.page-content -->
    </div>
</div><!-- /.main-content -->



<?php
include "footer.php";
?>