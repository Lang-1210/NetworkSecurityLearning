<?php
/**
 * Created by runner.han
 * There is nothing new under the sun
 * */

include_once 'inc/config.inc.php';

include "header.php";

$html = "";
try {
    mysqli_connect(DBHOST, DBUSER, DBPW, DBNAME);
} catch (Exception $e) {
    $html .=
        "<p >
        <a href='install.php' style='color:red;'>
        提示:欢迎使用,pikachu还没有初始化，点击进行初始化安装!
        </a>
    </p>";
}

?>

<div class="main-content">
    <div class="main-content-inner">

        <div class="page-content">
            <?php echo $html; ?>
            <div id="intro_main">


                <ul class="vul_list_info">
                    <li>Burt Force(暴力破解漏洞)</li>
                    <li>XSS(跨站脚本漏洞)</li>
                    <li>CSRF(跨站请求伪造)</li>
                    <li>SQL-Inject(SQL注入漏洞)</li>
                    <li>RCE(远程命令/代码执行)</li>
                    <li>Files Inclusion(文件包含漏洞)</li>
                    <li>Unsafe file downloads(不安全的文件下载)</li>
                    <li>Unsafe file uploads(不安全的文件上传)</li>
                </ul>
                </p>
            </div>


        </div><!-- /.page-content -->
    </div>
</div><!-- /.main-content -->



<?php
include "footer.php";
?>